#include <cstdio>
#include "solve.h"

using namespace std;

int main() {
	long long a, b;
	scanf("%lld %lld\n", &a, &b);
	fclose(stdin);

	printf("Hello, World!\n%lld\n", solve(a, b));
}
